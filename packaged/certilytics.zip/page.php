<?php get_header(); ?>

	<div class="c-page c-page-default">
		
		<?php get_template_part('includes/page-header'); ?>
		
		<?php get_template_part('includes/content-blocks'); ?>
		
		<?php get_template_part('includes/bottom-cta'); ?>

	</div>
	<!-- end .c-page -->

<?php get_footer(); ?>