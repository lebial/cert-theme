<?php
// Template Name: New Home Page Tempatle alternate
?>

<?php get_header() ?>

    <?php get_template_part('components/new-homepage/schedule_demo_modal') ?>
    <?php get_template_part('components/new-homepage/alternate_heros/new-hero-alternate') ?>
    <?php get_template_part('components/new-homepage/ai_driven_solutions') ?>
    <?php get_template_part('components/new-homepage/data_prediction_platform') ?>
    <?php get_template_part('components/new-home/credibility') ?>
    <?php get_template_part('components/new-home/insights') ?>
    <?php get_template_part('components/new-home/schedule-demo') ?>
<?php get_footer() ?>