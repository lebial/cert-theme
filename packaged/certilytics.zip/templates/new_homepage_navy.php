<?php
// Template Name: New Home Page Navy Tempatle
?>

<?php get_header() ?>

<? //php // get_template_part('components/new-homepage/schedule_demo_modal') 
?>
<?php get_template_part('components/new-home-navy/new-hero') ?>
<?php get_template_part('components/new-home-navy/ai_driven_solutions') ?>
<?php get_template_part('components/new-home-navy/data_prediction_platform') ?>
<?php get_template_part('components/new-home-navy/credibility') ?>
<?php get_template_part('components/new-home-navy/insights') ?>
<?php get_template_part('components/new-home-navy/schedule-demo') ?>
<?php get_footer() ?>