<?php
// Template Name: New Home Page Dark Full Tempatle
?>

<?php get_header() ?>

    <?php get_template_part('components/new-home-dark-full/new-hero') ?>
    <?php get_template_part('components/new-home-dark-full/ai_driven_solutions') ?>
    <?php get_template_part('components/new-home-dark-full/data_prediction_platform') ?>
    <?php get_template_part('components/new-home-dark-full/credibility') ?>
    <?php get_template_part('components/new-home-dark-full/insights') ?>
    <?php get_template_part('components/new-home-dark-full/schedule-demo') ?>
<?php get_footer() ?>