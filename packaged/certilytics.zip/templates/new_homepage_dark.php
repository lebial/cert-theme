<?php
// Template Name: New Home Page Dark Tempatle
?>

<?php get_header() ?>

    <?php get_template_part('components/new-home-dark/schedule_demo_modal') ?>
    <?php get_template_part('components/new-home-dark/new-hero') ?>
    <?php get_template_part('components/new-home-dark/ai_driven_solutions') ?>
    <?php get_template_part('components/new-home-dark/data_prediction_platform') ?>
    <?php get_template_part('components/new-home-dark/credibility') ?>
    <?php get_template_part('components/new-home-dark/insights') ?>
    <?php get_template_part('components/new-home-dark/schedule-demo') ?>
<?php get_footer() ?>