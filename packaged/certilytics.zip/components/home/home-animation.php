
<div class="w-full">
  <?php get_template_part('components/home/animation/first-slide') ?>
  <?php get_template_part('components/home/animation/second-slide') ?>
</div>