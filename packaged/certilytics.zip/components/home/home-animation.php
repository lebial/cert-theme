
<div class="w-full" id="<?php the_field('slideshow_section_id')?>">
  <?php get_template_part('components/home/animation/first-slide') ?>
  <?php get_template_part('components/home/animation/second-slide') ?>
</div>