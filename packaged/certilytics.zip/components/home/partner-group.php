
<div class="py-20  w-full border-b border-gray-400 border-solid">
  <div class="flex flex-col items-center px-12 md:px-0" data-aos="fade-up">
    <h3 class="text-center text-3xl md:text-2xl"><?php the_field('partner_group_title') ?></h3>
    <p class="mt-5 text-center leading-normal"><?php the_field('partner_group_description') ?></p>
  </div>
  <section class="flex justify-center w-full mt-8 md:mt-20" data-aos="fade-up">
    <div class="partner__group__container w-full md:w-7/12">
      <?php
        custom_get_gallery_image_as_svg('partner_group');
      ?>
    </div>
  </section>
</div>