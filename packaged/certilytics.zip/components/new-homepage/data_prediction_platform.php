<section class="w-full bg-dark-blue-background my-12 py-12">
  <h3 class="text-white font-bold text-4xl reveal-text">Certilytics Data & Prediction Platform</h3>
  <div class="text_container w-full flex flex-col items-center">
    <p class="text-white text-center text-base max-w-2xl">
      Our platform makes your data more powerful. We sill unify all your data into a single source of truth and enhance it
      with our proprietari AI-and machine learning-driven predictive analytics to provide insights that drive real, actionable change.
    </p>
    <a href="/platforms" class="px-2 py-1 mt-8 border border-primary text-white border-solid rounded-2xl transition-all duration-300 hover:bg-primary">Explore Platform</a>
  </div>
  <div class="data_path_animation w-full flex">
    <div class="w-4/12 flex flex-col justify-center ml-[10%]">
      <div class="flex w-full justify-between bottom-reveal">
        <p class="text-white mb-0">data ingested</p>
        <p class="text-primary font-bold">2.5Pb</p>
      </div>
      <div class="w-full">
        <div class="flex w-full justify-between">
          <p class="text-white">lives processed</p>
          <p class="text-primary font-bold">+200 Mil</p>
        </div>
      </div>
      <div class="w-full flex justify-between">
        <p class="text-white">claims inriched</p>
        <p class="text-primary font-bold">+50 Bil</p>
      </div>
      <div class="w-full flex justify-between">
        <p class="text-white">models scored</p>
        <p class="text-primary font-bold">+1 Bil</p>
      </div>
    </div>
    <div class="w-8/12">
      <?php get_template_part('components/new-homepage/graphic_animation') ?>
    </div>
  </div>

</section>