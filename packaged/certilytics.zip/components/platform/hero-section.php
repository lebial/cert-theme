<section class="platform-hero w-screen">
  <div class="pt-8 w-full px-14 flex flex-col items-center" data-aos="fade-up">
    <h1 class=" text-3xl text-gray-600 my-5"><?php the_field('head_line')?></h1>
    <p class="text-lg"><?php the_field('head_line_description')?></p>
  </div>
</section>