<section class="platform-hero w-screen">
  <div class="pt-2 w-full px-14 flex flex-col items-center" data-aos="fade-up">
    <div class="w-full lg:w-8/12 ">
      <h1 class=" text-xl lg:text-2xl text-center lg:text-left text-gray-600 my-5"><?php the_field('head_line')?></h1>
    </div>
  </div>
</section>