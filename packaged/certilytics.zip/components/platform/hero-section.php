<section class="platform-hero w-screen">
  <div class="pt-8 w-full px-14 flex flex-col items-center">
    <h1 class=" text-4xl text-gray-600 my-5"><?php the_field('head_line')?></h1>
    <p class="text-2xl"><?php the_field('head_line_description')?></p>
  </div>
</section>