<section class="platform-hero w-screen">
</section>