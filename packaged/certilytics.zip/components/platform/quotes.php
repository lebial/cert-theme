<section class="quotes__section w-screen bg-gray-secondary px-12 lg:px-0">
  <div class="quotes__slider flex justify-center items-center h-full">
    <div class="quotes__card px-12 py-12 my-20">
      <div class="dquote dquote-top"><span>“</span></div>
      <div class="dquote dquote-bottom"><span>”</span></div>
      <p class="text-lg">Certilytics' product set is built with modern tools and techniques, including open source software and tools.
        ...Its modern technology stack distinguishes it from other payer-oriented analytics vendors. In addition to technology, Certilytics offers implementation services, ongoing product maintenance and resourcebundle_localessupport,
        and data science-services.
      </p>
      <!-- <p class=" text-xl font-bold">—Chilmark Research 2019
        Payer Analytics Market 
        Trends Report
      </p> -->
    </div>
  </div>
</section>