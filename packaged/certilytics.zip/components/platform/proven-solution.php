<section class="w-screen h-screen  bg-blue-600 mt-8">
  <h2 class="text-white pt-8 mb-5 text-center">test title<?php the_field('solution_title')?></h2>
  <div class="solution__content flex flex-col justify-evenly items-center">
    <div class="solution__content__data flex items-center ">
      <h3>1.7 PB</h3> <p>of data under management</p>
    </div>
    <div class="solution__content__data flex items-center">
      <h3>1.7 PB</h3> <p>of data under management</p>
    </div>
    <div class="solution__content__data flex items-center">
      <h3>1.7 PB</h3> <p>of data under management</p>
    </div>
    <div class="solution__content__data flex items-center">
      <h3>1.7 PB</h3> <p>of data under management</p>
    </div>
    <div class="solution__content__data flex items-center">
      <h3>1.7 PB</h3> <p>of data under management</p>
    </div>
  </div>
</section>