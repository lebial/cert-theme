<section class="new_approach_to_value w-full flex">
  <div class="w-1/2 bg-dark-blue-background"></div>
  <div class="w-1/2 "></div>
</section>