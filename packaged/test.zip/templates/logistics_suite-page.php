<?php
// Template Name: Logistics Page
?>

<?php get_header(); ?>
<?php get_template_part('components/logistics-suite/hero-logistics') ?>
<?php get_template_part('components/new-platform/highlight-video') ?>
<?php get_template_part('components/logistics-suite/data-processing') ?>
<?php get_template_part('components/logistics-suite/validation-process') ?>
<?php get_template_part('components/logistics-suite/security-framework') ?>
<?php get_template_part('components/new-platform/ia-insights') ?>
<?php get_template_part('components/platform/contact-us') ?>
<?php get_footer(); ?>
