<?php
// Template Name: Brainstorm AI
?>


<?php get_header(); ?>
<?php get_template_part('components/brainstorm-ai/brainstorm-ai-hero') ?>
<?php get_template_part('components/brainstorm-ai/highlight-video') ?>
<?php get_template_part('components/brainstorm-ai/cert-timeline') ?>
<?php get_template_part('components/brainstorm-ai/brainstorm_ai_highlight') ?>
<?php get_template_part('components/new-platform/ia-insights') ?>
<?php get_template_part('components/platform/contact-us') ?>
<?php get_footer(); ?>