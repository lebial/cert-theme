<?php
// Template Name: About Us Page
?>

<?php get_header() ?>
<?php get_template_part('components/about-us/au-heading') ?>
<?php get_template_part('components/about-us/au-story') ?>
<?php get_template_part('components/about-us/au-new-approach-to-vale') ?>
<?php get_template_part('components/about-us/au-solutions') ?>
<?php get_template_part('components/about-us/au-our-team') ?>
<?php get_template_part('components/about-us/au-careers') ?>
<?php //get_template_part('components/about-us/au-story-slider') 
?>
<?php get_template_part('components/about-us/au-contact-us') ?>
<?php get_footer() ?>